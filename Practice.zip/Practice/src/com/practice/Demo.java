package com.practice;

import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.BiPredicate;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.stream.IntStream;

public class Demo {
	
	public static boolean isCCCEqualToThreeTimesABC(int i) {

		int actual = 3*i;
		String num = String.valueOf(i);
		char lastDigit = num.charAt(num.length() - 1);
		String expectedString = String.valueOf(lastDigit).repeat(3);
		return (actual == Integer.valueOf(expectedString));
	}

	public static void main(String[] args) {

		// Supplier to generate random number
		Supplier<Double> randomNumberSupplier = () -> {
			Double num = Math.random();
			if (num > 0.5) {
				return Double.valueOf("1");
			} else {
				return Double.valueOf("2");
			}
		};
		
		Double randomNumber = randomNumberSupplier.get();
		
		// Consumer to print the random number
		Consumer<Double> randomNumberPrinter = (num) -> {
			System.out.println("Random Number: " + num);
		};
		randomNumberPrinter.accept(randomNumber);
		
		// Predicate to check if the number is even
		Predicate<Double> evenNumberPredicate = (num) -> {
			return num%2 == 0;
		};
		
		boolean isEvenNumber = evenNumberPredicate.test(randomNumber);
		System.out.println("Is even number: " + isEvenNumber);
		
		// Function to convert double into integer
		Function<Double, Integer> doubleToIntegerConverter = (num) -> {
			return num.intValue();
		};
		System.out.println("Converted Integer: " + doubleToIntegerConverter.apply(randomNumber));
		
		// BiConsumer to print two numbers
		BiConsumer<Integer, Integer> numberPrinter = (num1, num2) -> {
			System.out.println("2 Integers: " + num1 + " and " + num2);
		};
		numberPrinter.accept(1, 8);
		
		// BiFunction to add two numbers
		BiFunction<Integer, Integer, Integer> numberAdder = (num1, num2) -> {
			return num1 + num2;
		};
		Integer sum = numberAdder.apply(1, 8);
		System.out.println("Sum: " + sum);
		
		// BiPredicate to check two numbers are divisible
		BiPredicate<Integer, Integer> divisibleChecker = (num1, num2) -> {
			return num1%num2 == 0;
		};
		boolean isDivisible = divisibleChecker.test(4, 2);
		System.out.println("Is Divisible: " + isDivisible);
		
		Runnable printNumber = () -> {
			for(int i = 1; i < 10; i++) {
				System.out.println(i);
			}
		};
		Thread thread = new Thread(printNumber);
		thread.start();
		
		Supplier<Employee> createEmployee = () -> {
			return new Employee(1, "Jay", "chennai", "software engineer", 25,12312);
		};
		Employee emp = createEmployee.get();
		
		Consumer<Employee> printEmployee = (employee) -> {
			System.out.println("Id: " + employee.getId());
			System.out.println("Name: " + employee.getName());
		};
		printEmployee.accept(emp);
		
		Predicate<Employee> empPredicate = (employee) -> {
			return employee.getCity() == "chennai";
		};
		System.out.println("Is the employee based in chennai: " + empPredicate.test(emp));
		
		Function<Employee, String> getDesignation = (employee) -> {
			return employee.getDesignation();
		};
		System.out.println("Designation: " + getDesignation.apply(emp));
		
		IntStream.range(100, 999).filter(integer -> isCCCEqualToThreeTimesABC(integer)).forEach(System.out::println);
	}
}
