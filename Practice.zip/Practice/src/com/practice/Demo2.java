package com.practice;

import java.time.Instant;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.stream.Collectors;

public class Demo2 {
	
	public static String getAgeRange(int age) {
		
		String ageGroup = new String();
		if (age > 20 && age < 30) {
			ageGroup = "20s";
		} else if (age > 30 && age < 40) {
			ageGroup = "30s";
		} else if (age < 20) {
			ageGroup = "Late teen";
		}
		return ageGroup;
	}
	
	public static void main(String[] args) {

		Employee emp = new Employee(1, "Jayanth", "Chennai", "Software Engineer", 37, 11111);
		Employee emp1 = new Employee(2, "Vinoth", "Chennai", "Senior Software Engineer", 41, 11234);
		Employee emp2 = new Employee(3, "Reshmi", "Chennai", "Senior Software Engineer", 39, 12345);
		Employee emp3 = new Employee(4, "Reshmi", "Chennai", "Junior Software Engineer", 42, 12345);
		Employee emp4 = new Employee(5, "Thiru", "Chennai", "Software Engineer", 17, 21245);
		
		CopyOnWriteArrayList<Employee> employees = new CopyOnWriteArrayList<Employee>();
		employees.add(emp4);
		employees.add(emp3);
		employees.add(emp2);
		employees.add(emp1);
		employees.add(emp);

		// sort the values based on age
		List<Employee> sortedEmployeesAgedMoreThan30 = employees.stream().sorted(Comparator.comparing(Employee::getAge)).filter(employee -> employee.getAge() > 30).collect(Collectors.toList());
		
		sortedEmployeesAgedMoreThan30.stream().forEach(employee -> {
			if (employee.getAge() > 40) {
				employee.setSalary(employee.getSalary() + 10);
			}
		});
		
		sortedEmployeesAgedMoreThan30.stream().forEach(empl -> System.out.println(empl.getName() + " - " + empl.getSalary()));
		
		Map<String, List<Employee>> employeeNameGroups = employees.stream().collect(Collectors.groupingBy(empl -> empl.getName(), Collectors.toList()));
		
		employeeNameGroups.forEach((key, val) -> System.out.println(key + ", "+ val));
		
		List<String> nickNames = employees.stream().map(empl -> empl.getName() + "Ji").collect(Collectors.toList());
		Map<Object, List<Employee>> ageCount = employees.parallelStream().collect(Collectors.groupingBy(empl -> Demo2.getAgeRange(empl.getAge()), Collectors.toList()));
		ageCount.forEach((key, val) -> System.out.println(key + " - " + val));
		
		Map<String, List<Employee>> map = employees.stream().collect(Collectors.groupingBy(Employee::getName));
		map.forEach((key, val) -> val.forEach(empl -> System.out.println(key + ", " + empl.getId())));
		
		employees.stream().filter(empl -> ((empl.getAge() > 20) && (empl.getAge() < 30))).forEach(empl -> System.out.println(empl.getName()));
		
		long time = Instant.now().getEpochSecond();
		
		employees.stream().forEach(employee -> {
			if (time % 2 ==0) {
				employee.setAge(employee.getAge() + 2);
			} else {
				employee.setAge(employee.getAge() + 1);
			}
		});
		
		employees.forEach(empl -> empl.getAge());
	}
}