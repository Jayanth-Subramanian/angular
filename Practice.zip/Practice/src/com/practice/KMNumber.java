package com.practice;

import java.util.Scanner;

class KMNumber {

	public static int factorial(int number) {

		int factorial = 1;
		while (number != 0) {
			factorial = factorial * number;
			number--;
		}
		return factorial;
	}

	public static boolean checkNumber(int number) {

		int sum = 0;
		int tempNumber = number;

		while (tempNumber != 0) {
			sum = sum + factorial(tempNumber % 10);
			tempNumber = tempNumber / 10;
		}

		return (sum == number) ? true : false;
	}

	public static void main(String[] args) {
		
		int n;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter any number:");

		n = sc.nextInt();
		if (checkNumber(n))
			System.out.println(n + " is a krishnamurthy number");
		else
			System.out.println(n + " is not a krishnamurthy number");
		sc.close();
	}
}