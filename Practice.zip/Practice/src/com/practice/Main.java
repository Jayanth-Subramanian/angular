package com.practice;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Main {

	public static void main(String[] args) {

		System.out.println("-------------------Printing list of lists using flatmap: -----------------");
			List<Integer> PrimeNumbers = Arrays.asList(5, 7, 11, 13);
			List<Integer> OddNumbers = Arrays.asList(1, 3, 5);
			List<Integer> EvenNumbers = Arrays.asList(2, 4, 6, 8);
			List<List<Integer>> listOfListofInts = Arrays.asList(PrimeNumbers, OddNumbers, EvenNumbers);
			
			List<Integer> ints = listOfListofInts.stream().flatMap(List::stream).collect(Collectors.toList());
			System.out.println(ints);
			
		System.out.println("------------------Finding frequency in a list: ------------------");
		List<String> strings = Arrays.asList("apple", "grape", "apple", "pear", "pineapple", "melon", "apple", "pear");
		
		Map<String, Long> bag =
				   strings.stream()
				          .collect(Collectors.groupingBy(Function.identity(), 
				        		  						 Collectors.counting()));
		bag.forEach((word, count) -> System.out.println(word + " - " + count));
		
		// Adding all even numbers
		List<Integer> number = Arrays.asList(1,2,3,4,5,6,7,8,9,10);
		
		boolean isAllEven = number.stream().map(num -> num%2 == 0).reduce(Boolean::logicalAnd).get().booleanValue();
		System.out.println("Is all even: " + isAllEven);
		System.out.println("Sum of all numbers: " + number.stream().reduce(Integer::sum).get());
		int even = (int) number.stream().filter(x -> number.indexOf(x)%2==0).reduce((ans,i) -> ans + i).get();
		System.out.println("Even: " + even);
		
		int max = number.stream().reduce((i1, i2) -> i1 > i2 ? i1 : i2).get();
		System.out.println("Max Integer: " + max);
		
		System.out.println("Max Length : " + strings.stream().reduce((string, nextString) -> string.length() > nextString.length() ? string : nextString).get());
		System.out.println("Max Length : " + strings.stream().max(Comparator.comparingInt(String::length)).get());
		
		System.out.println("--------------Employee Fields as a list: -----------------");
		Employee emp = new Employee(1, "Jayanth", "Chennai", "Software Engineer", 25, 12345);
		List<Object> fieldValue = Arrays.stream(Employee.class.getDeclaredFields()).map(field -> {
			try {
				field.setAccessible(true);
				return field.get(emp);
			} catch (IllegalArgumentException e) {
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				e.printStackTrace();
			}
			return field;
		}).collect(Collectors.toList());
		System.out.println(fieldValue);
		
		System.out.println("--------Map of Employee fields--------");
		Map<String, Object> fieldValueMap = Arrays.stream(Employee.class.getDeclaredFields())
			  .collect(Collectors.toMap(Field::getName, field -> {
			            try {
			              field.setAccessible(true);
			              return field.get(emp);
			            } catch (Exception e) {
			            }
			            return field;
			          }));
		fieldValueMap.forEach((key, value) -> System.out.println(key + " - " + value));
		
		System.out.println("------Prime numbers---------");
		number.stream().filter(num -> num > 1)
					   .filter(num -> IntStream.rangeClosed(2, num/2).noneMatch(integer -> num % integer == 0))
					   .forEach(System.out::println);
		
		String str1 = "race";
		String str2 = "care";
		char[] char1 = str1.toCharArray();
		char[] char2 = str2.toCharArray();
		Arrays.sort(char1);
		Arrays.sort(char2);
		if (Arrays.equals(char1, char2)) {
			System.out.println(str1 + " and " + str2 + " are anagrams");
		} else {
			System.out.println(str1 + " and " + str2 + " are not anagrams");
		}
		
		List<Employee> emps = new ArrayList<Employee>();
		emps.add(emp);
		Map<Integer, Employee> empMap = emps.stream().collect(Collectors.toMap(Employee::getId, Function.identity()));
		empMap.forEach((key, val) -> System.out.println(key + " - " + val.getName()));
		
		Map<String, Integer> map = new HashMap<String, Integer>();
		map.put("Kavin", 17);
		map.put("Jay", 27);
		map.put("Agrasha", 27);
		map.put("Reshmi", 28);
		map.put("Vinoth", 36);
		map.put("Aravind", 30);
		
		// Iterate and get all values in a list
		List<Integer> ages = map.values().stream().collect(Collectors.toList());
		System.out.println("All Ages: " + ages);
		
		// Iterate and find names which start with 'a'
		System.out.println("Names starting with A: ");
		map.keySet().stream().filter(key -> (key.startsWith("a") || key.startsWith("A"))).forEach(System.out::println);
		
		// Iterate and get the oldest integer's name alone as a return string value
		String name = map.entrySet().stream().sorted(Map.Entry.comparingByValue(Comparator.reverseOrder())).findFirst().get().getKey();
		
		System.out.println("Oldest Person's Name: " + name);
		System.out.println("Oldest Person's Name: " + Collections.max(map.entrySet(), Map.Entry.comparingByValue()).getKey());
	}
}
