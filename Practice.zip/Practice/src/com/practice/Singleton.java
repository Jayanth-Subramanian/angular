package com.practice;

public class Singleton {

	private static Singleton singleton;
	
	public String str;

	private Singleton() {
		str = "it is an example of singleton class."; 
	}
	
	public static synchronized Singleton getInstance() {

		if (singleton == null) {
			return new Singleton();
		} else {
			return singleton;
		}
	}
}
