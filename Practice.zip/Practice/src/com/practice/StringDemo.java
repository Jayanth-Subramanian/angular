package com.practice;

import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class StringDemo {

	public static void main(String[] args) {
		
		// String operations in Java 11
		String str = " Sample String ";
		if (str.isBlank()) {
			System.out.println("String is blank");
		} else {
			System.out.println("String is not blank");
		}

		String strippedStr = str.strip();
		System.out.println("Stripped str : " + strippedStr);
		System.out.println("Stripped only leading: " + str.stripLeading());
		System.out.println("Stripped only trailing: " + str.stripTrailing());
		
		System.out.println("String repeated 3 times: " + str.repeat(3).strip());
		
		String multipleLines = "Hello\n"
							 + "good morning\n"
							 + "all is well";
		multipleLines.lines().map(line -> line.toUpperCase()).forEach(System.out::println);
		
		// var keyword in lambda expressions
		// Not predicate
		List<String> sampleList = Arrays.asList("Hello", " ", "World!");
		System.out.println(sampleList.stream()
							  		  .map((var x) -> x.toUpperCase())
							  		  .filter(Predicate.not(String::isBlank))
							  		  .collect(Collectors.joining("")));
		// Collections to Array
		String[] sampleArray = sampleList.toArray(String[]::new);
		System.out.println(sampleArray[0]);
	}
}
