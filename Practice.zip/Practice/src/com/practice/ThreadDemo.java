package com.practice;

import java.util.concurrent.Callable;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ThreadDemo {

	public static void main(String[] args) throws InterruptedException, ExecutionException {
		
		ExecutorService executor = Executors.newFixedThreadPool(10);

		executor.execute(() -> {
			System.out.println("Test");
		});

		CompletableFuture<Integer> greetingFuture = CompletableFuture.supplyAsync(() -> {
			// some async computation
			return 1;
		});

		System.out.println(greetingFuture.get());

		String inputStr = "Hello";
		CompletableFuture<Void> getInt = CompletableFuture.runAsync(() -> {
	        
	        System.out.println("async command : " + inputStr);
		});
		
		getInt.get();
	}
}
